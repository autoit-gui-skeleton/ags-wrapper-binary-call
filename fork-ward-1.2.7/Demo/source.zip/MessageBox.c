#include <windows.h>

void main()
{
	MessageBox(0, "Hello", "Welcome Message", 1);
}
